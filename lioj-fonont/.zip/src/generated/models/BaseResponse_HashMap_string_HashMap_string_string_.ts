/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type BaseResponse_HashMap_string_HashMap_string_string_ = {
    code?: number;
    data?: Record<string, Record<string, string>>;
    message?: string;
};

