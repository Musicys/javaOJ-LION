/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Page_Commentson_ } from './Page_Commentson_';
import type { Usercoment } from './Usercoment';
export type DtoComment = {
    chiden?: Page_Commentson_;
    content?: string;
    createtime?: string;
    good?: number;
    id?: number;
    like?: boolean;
    usercoment?: Usercoment;
};

