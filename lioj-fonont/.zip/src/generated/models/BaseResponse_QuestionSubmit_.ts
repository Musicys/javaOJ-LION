/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { QuestionSubmit } from './QuestionSubmit';
export type BaseResponse_QuestionSubmit_ = {
    code?: number;
    data?: QuestionSubmit;
    message?: string;
};

