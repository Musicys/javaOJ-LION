/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { QuestionComment } from './QuestionComment';
import type { Usercoment } from './Usercoment';
export type DtoRequested = {
    content?: string;
    createtime?: string;
    good?: number;
    id?: number;
    like?: boolean;
    pid?: number;
    questionComment?: QuestionComment;
    questionId?: number;
    requested?: boolean;
    usercoment?: Usercoment;
};

