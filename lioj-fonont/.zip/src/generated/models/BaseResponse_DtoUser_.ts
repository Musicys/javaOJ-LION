/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DtoUser } from './DtoUser';
export type BaseResponse_DtoUser_ = {
    code?: number;
    data?: DtoUser;
    message?: string;
};

