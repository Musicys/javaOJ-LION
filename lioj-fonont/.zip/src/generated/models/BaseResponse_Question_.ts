/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Question } from './Question';
export type BaseResponse_Question_ = {
    code?: number;
    data?: Question;
    message?: string;
};

