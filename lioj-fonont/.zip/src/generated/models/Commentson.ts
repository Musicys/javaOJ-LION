/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Usercoment } from './Usercoment';
export type Commentson = {
    content?: string;
    createtime?: string;
    good?: number;
    id?: number;
    like?: boolean;
    name?: string;
    usercoment?: Usercoment;
    userid?: number;
};

