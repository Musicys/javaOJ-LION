/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Page_DtoComment_ } from './Page_DtoComment_';
export type BaseResponse_Page_DtoComment_ = {
    code?: number;
    data?: Page_DtoComment_;
    message?: string;
};

