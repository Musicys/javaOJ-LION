/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Page_Commentson_ } from './Page_Commentson_';
export type BaseResponse_Page_Commentson_ = {
    code?: number;
    data?: Page_Commentson_;
    message?: string;
};

