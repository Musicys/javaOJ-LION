/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type Requested = {
    current?: number;
    pageSize?: number;
    sortField?: string;
    sortOrder?: string;
};

