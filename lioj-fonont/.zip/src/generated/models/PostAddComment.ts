/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type PostAddComment = {
    commentid?: number;
    commentids?: number;
    content?: string;
    pid?: number;
    questionid?: number;
};

