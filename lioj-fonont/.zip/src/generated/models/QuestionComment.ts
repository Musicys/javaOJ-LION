/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type QuestionComment = {
    commentid?: number;
    commentids?: number;
    content?: string;
    createtime?: string;
    id?: number;
    pid?: number;
    questionid?: number;
    requested?: boolean;
    updatetime?: string;
    userid?: number;
};

