/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type PostListComment = {
    current?: number;
    pageSize?: number;
    pid?: number;
    questionid?: number;
    sortField?: string;
    sortOrder?: string;
};

