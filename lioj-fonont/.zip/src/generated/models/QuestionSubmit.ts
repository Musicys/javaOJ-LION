/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type QuestionSubmit = {
    code?: string;
    createTime?: string;
    id?: number;
    isDelete?: number;
    judgeInfo?: string;
    language?: string;
    questionId?: number;
    status?: number;
    updateTime?: string;
    userId?: number;
};

