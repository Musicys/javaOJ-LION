/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { QuesitonSumbitNumber } from './QuesitonSumbitNumber';
export type DtoUser = {
    createTime?: string;
    id?: number;
    qqEmail?: string;
    quesitonSumbitNumber?: QuesitonSumbitNumber;
    updateTime?: string;
    userAvatar?: string;
    userName?: string;
    userProfile?: string;
    userRole?: string;
};

