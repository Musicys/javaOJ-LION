/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Page_DtoRequested_ } from './Page_DtoRequested_';
export type BaseResponse_Page_DtoRequested_ = {
    code?: number;
    data?: Page_DtoRequested_;
    message?: string;
};

