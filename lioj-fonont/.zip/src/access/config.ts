//权限配置文件
export const ACCESS_ENUM = {
        NO_LOGIN: "notLogin",
        USER: "user",
        ADMIN: "admin"
}